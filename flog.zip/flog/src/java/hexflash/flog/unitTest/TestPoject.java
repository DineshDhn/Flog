/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hexflash.flog.unitTest;

//import hexflash.flog.data.Db;
import hexflash.flog.models.FlogElement;
import hexflash.flog.models.FunctionElement;
import hexflash.flog.models.LetterElement;
import hexflash.flog.models.Player;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Sithum
 */
public class TestPoject {
    public static void main(String[] args) {
        System.out.println("Starting...");
        
//        Player player = new Player();
//        player.setName("Another1");
//        player.setDetails("Another details1");
//        
//        // insert 
//        
//        SessionFactory factory =  Db.getSessionFactory();
//        Session s = factory.openSession();
//        s.beginTransaction();
//        s.save(player);
//        s.getTransaction().commit();
//        s.close();
//        
//        // update 
//        
//        s = factory.openSession();
//        s.beginTransaction();
//        player.setName("edited name");
//        s.update(player);
//        s.getTransaction().commit();
//        s.close();
                
        // delete 
        //s.beginTransaction();
        //s.delete(player);
        //s.getTransaction().commit();

        // search 
        //s.beginTransaction();
        //s.save(player);
        //s.getTransaction().commit();
        
        
        
//        System.out.println("End...");
//        System.exit(0);
        
        FlogElement.createAlphabet();
        LetterElement[] initLetters = FunctionElement.getInitial();
        System.out.println("Letter : " + initLetters[1].getLetter() + " Value : " + initLetters[1].getValue());
    }
}
