/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hexflash.flog.models;

/**
 *
 * @author Dinesh
 */
public class FlogElement {
    private static LetterElement[] alphabet;
    
    public static void createAlphabet(){
        alphabet = new LetterElement[26];
        LetterElement A = new LetterElement();
        A.setLetter("A");
        A.setValue(1);
        LetterElement B = new LetterElement();
        A.setLetter("B");
        A.setValue(1);
        LetterElement C = new LetterElement();
        A.setLetter("C");
        A.setValue(1);
        LetterElement D = new LetterElement();
        A.setLetter("D");
        A.setValue(1);
        
        alphabet[1] = A;
        alphabet[2] = B;
        alphabet[3] = C;
        alphabet[4] = D;
    }
    
    public static LetterElement[] getAlphabet(){
        return alphabet;
    }
    
    public static int getValueByLetter(String letter){
        for (LetterElement alphabet1 : alphabet) {
            if (alphabet1.getLetter().equals(letter)) {
                return alphabet1.getValue();
            }
        }
        return 0;
    }
}
