/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hexflash.flog.models;

import java.util.Random;


/**
 *
 * @author Dinesh
 */
public class FunctionElement {
    private static LetterElement [] alphabet;
    public static LetterElement[] getInitial(){
        LetterElement [] letters = new LetterElement[2];
        alphabet = FlogElement.getAlphabet();
        for (int i = 0; i < 2; i++) {
            int rnd = new Random().nextInt(alphabet.length);
            letters[i] = alphabet[rnd];
        }       
        return letters;
    }
    
    public LetterElement[] getLetters(int vowels,int constant){
        LetterElement [] letters = new LetterElement[10];
        alphabet = FlogElement.getAlphabet();
        int rnd;
        for (int i = 0; i < 10; i++) {
            rnd = new Random().nextInt(alphabet.length);
            String letter = alphabet[rnd].getLetter();
            if(letter.equals("A") || letter.equals("E") || letter.equals("I") || letter.equals("O") || letter.equals("U")){
                if (vowels != 0) {
                    letters[i] = alphabet[rnd];
                    vowels -= 1;
                }                
            }
            else{
                if (constant != 0) {
                    letters[i] = alphabet[rnd];
                    constant -= 1;
                }
            }
        }
        return letters;
    }
    
    public boolean isValidWord(String word){        
        boolean isValid = false;
        //code for word validation
        
        return isValid;
    }
    
    public int calculateScore(String word,int timetakken,LetterElement[] givenInitials,LetterElement[] givenLetters){
        int usedInitials = 0;
        int basicScore = 0;
        if (isValidWord(word)) {
            //<editor-fold desc="start calculate basic score(sum of letter values + 10 points per letter)">
            int lettterValueScore = 0;            
            int noLetters = word.length();
            String [] strLetters = word.toUpperCase().split("(?!^)");
            for (String strLetter : strLetters) {
                lettterValueScore += FlogElement.getValueByLetter(strLetter);
            }
            basicScore = lettterValueScore + noLetters*10;
            //</editor-fold>
            
            //<editor-fold desc="start bonus 1) using initial letters--> 1 letter 30 points & 2 letters 100 points">
            for (String strLetter : strLetters) {
                if (usedInitials != 2) {
                    if (strLetter.equals(givenInitials[0].getLetter()) || strLetter.equals(givenInitials[1].getLetter())) {
                        usedInitials += 1;
                    }
                } else {
                    break;
                }              
            }
            
            if (usedInitials == 2) {
                basicScore += 100;
            }
            else if (usedInitials == 1) {
                basicScore += 30;
            }
            //</editor-fold>
            
            
            
            return basicScore;
        }
        else{
            return basicScore;
        }      
    }
}
